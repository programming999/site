import products from './data';

const queries = {
  async products() {
    return products;
  },
};

export default queries;
