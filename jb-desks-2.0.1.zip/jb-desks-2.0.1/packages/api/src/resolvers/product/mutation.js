import products from './data';

const mutations = {
  async createProduct(_, product) {
    return product;
  },
};

export default mutations;
