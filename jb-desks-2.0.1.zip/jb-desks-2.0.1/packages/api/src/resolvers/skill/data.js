export default [
  {
    id: 1,
    name: 'laravel',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb1.png',
  },
  {
    id: 2,
    name: 'Wordpress',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb2.png',
  },
  {
    id: 3,
    name: 'AngularJS',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb3.png',
  },
  {
    id: 4,
    name: 'node js',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb4.png',
  },
  {
    id: 5,
    name: '1onic',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb5.png',
  },
  {
    id: 6,
    name: 'node js',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb4.png',
  },
];
