import products from './data';

const queries = {
  async skill() {
    return products;
  },
};

export default queries;
