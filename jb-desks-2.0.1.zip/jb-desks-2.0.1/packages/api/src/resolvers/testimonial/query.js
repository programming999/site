import testimonial from './data';

const queries = {
  async testimonial() {
    return testimonial;
  },
};

export default queries;
