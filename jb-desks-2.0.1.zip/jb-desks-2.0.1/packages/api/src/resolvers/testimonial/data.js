export default [
  {
    id: 1,
    name: 'MARITA IRANE',
    description:
      "“ I don't always clap, but when I do, it'sbecause of Sella. We can't understandhow we've been Sella. ”",
    position: 'Support manager @ Eco',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/testi.png',
  },
  {
    id: 2,
    name: 'MARITA IRANE',
    description:
      "“ I don't always clap, but when I do, it'sbecause of Sella. We can't understandhow we've been Sella. ”",
    position: 'Support manager @ Eco',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/testi.png',
  },
  {
    id: 3,
    name: 'MARITA IRANE',
    description:
      "“ I don't always clap, but when I do, it'sbecause of Sella. We can't understandhow we've been Sella. ”",
    position: 'Support manager @ Eco',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/testi.png',
  },
  {
    id: 4,
    name: 'MARITA IRANE',
    description:
      "“ I don't always clap, but when I do, it'sbecause of Sella. We can't understandhow we've been Sella. ”",
    position: 'Support manager @ Eco',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/testi.png',
  },
];
