export default [
  {
    id: 1,
    name: 'developer',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb1.png',
    statics: 1450,
  },
  {
    id: 2,
    name: 'technology',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb2.png',
    statics: 4582,
  },
  {
    id: 3,
    name: 'accounting',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb3.png',
    statics: 3254,
  },
  {
    id: 4,
    name: 'medical',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb4.png',
    statics: 2578,
  },
  {
    id: 5,
    name: 'goverment',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb5.png',
    statics: 1547,
  },
  {
    id: 6,
    name: 'media & news',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb4.png',
    statics: 29547,
  },
  {
    id: 7,
    name: 'restaurents',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb4.png',
    statics: 7584,
  },
  {
    id: 8,
    name: 'design & creative',
    image:
      'https://webstrot.com/html/jbdesk/main_version/main_pages/images/jb4.png',
    statics: 7584,
  },
];
