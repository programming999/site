import category from './data';

const queries = {
  async category() {
    return category;
  },
};

export default queries;
