import React from 'react';

const HiringDetails = () => {
  return (
    <>
      <h2
        className="text-capitalize text-dark font-weight-normal mb-4"
        style={{ fontSize: '36px' }}
      >
        Top Hiring Companies
      </h2>
      <p className="text-muted">
        What do all consultants need? In short, trust. This is achieved with
        professional presentation and the ability to communicate. Clearly with
        existing and potential clients.ll consultants need? In short, trust.
        This is achieved with Whether you Whether you are an accountant.
      </p>
    </>
  );
};

export default HiringDetails;
