import React from 'react';

const BannerRight = () => {
  return (
    <div className="banner-right d-xl-block d-lg-none d-md-none d-sm-none d-xs-none d-none ml-1 position-relative" />
  );
};

export default BannerRight;
